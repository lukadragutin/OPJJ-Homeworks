package hr.fer.zemris.java.pred06;

import java.io.File;

public class PraznaObrada implements Obrada{

	@Override
	public void ulazimUDirektorij(File dir) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void izlazimIzDirektorija(File dir) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void imamDatoteku(File dir) {
		// TODO Auto-generated method stub
		
	}

}
