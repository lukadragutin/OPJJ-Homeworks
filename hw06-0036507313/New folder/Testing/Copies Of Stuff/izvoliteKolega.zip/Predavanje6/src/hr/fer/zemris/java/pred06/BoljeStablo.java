package hr.fer.zemris.java.pred06;

import java.io.File;

public class BoljeStablo extends Obilazak {
	
	public static void main(String[] args) {
		String filename = args[0];
		File file = new File(filename);
		Obilazak.obidi(file, new BoljeStabalce());
	}

	private static class BoljeStabalce implements Obrada {

		int razina;
		
		@Override
		public void ulazimUDirektorij(File dir) {
			System.out.println(" ".repeat(razina*2) + dir.getPath());
			razina++;
		}

		@Override
		public void izlazimIzDirektorija(File dir) {
			razina--;
		}

		@Override
		public void imamDatoteku(File dir) {
			System.out.println(" ".repeat(razina*2) + dir.getPath());
		}
		
	}
}
