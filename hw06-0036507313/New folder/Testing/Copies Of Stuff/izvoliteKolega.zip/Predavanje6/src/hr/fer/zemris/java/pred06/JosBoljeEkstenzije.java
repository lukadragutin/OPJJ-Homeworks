package hr.fer.zemris.java.pred06;

import java.io.File;
import java.util.HashMap;

public class JosBoljeEkstenzije extends PraznaObrada {

	HashMap<String, Integer> ekstenzije = new HashMap<>();

	public void imamDatoteku(File dir) {
		String ekstenzija = getEkstenzija(dir);
		ekstenzije.compute(ekstenzija, (k, v) -> v == null ? 1 : v + 1);
	}

	private static String getEkstenzija(File file) {
		String name = file.getName();
		if (name.lastIndexOf('.') > 0) {
			String ekst = name.substring(name.lastIndexOf('.') + 1).toLowerCase();
			return ekst;
		}
		return "";
	}
}
