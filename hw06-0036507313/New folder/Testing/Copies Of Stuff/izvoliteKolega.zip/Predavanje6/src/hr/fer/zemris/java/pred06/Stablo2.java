package hr.fer.zemris.java.pred06;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

public class Stablo2 {
	
	private static class Visit implements FileVisitor<Path> {

		private int razina;
		
		@Override
		public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
			System.out.println(" ".repeat(razina*2) + dir.toAbsolutePath());
			razina++;
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
			System.out.println(" ".repeat(razina*2) + file.toAbsolutePath());
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
			razina--;
			return FileVisitResult.CONTINUE;
		}
		
	}

	public static void main(String[] args) {
		Path root = Paths.get(args[0]);
		try {
			Files.walkFileTree(root, new Visit());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
