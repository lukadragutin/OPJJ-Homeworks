package hr.fer.zemris.java.pred06;

import java.io.File;

public class Obilazak {

	public static void obidi(File dir, Obrada obrada) {
		if(!dir.isDirectory()) {
			throw new RuntimeException();
		}
		obidiRekurzivno(dir, obrada);
	}

	private static void obidiRekurzivno(File dir, Obrada obrada) {
		File[] child = dir.listFiles();
		if (child != null) {
			for (File file : child) {
				if (file.isFile()) {
					obrada.imamDatoteku(file);
				} else if (file.isDirectory()) {
					obrada.ulazimUDirektorij(file);
					obidiRekurzivno(file, obrada);
				}
			}
		}
		obrada.izlazimIzDirektorija(dir);
	}

}
