package hr.fer.zemris.java.pred06;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Ekstenzije2 {

	static class Rezultat {
		public HashMap<String, Integer> ekstenzije = new HashMap<>();
		public File stazaDoNajveceDatoteke;
		private long velicinaNajveceDatoteke = -1;
	}

	public static void main(String[] args) {
		String pathname = args[0];
		File root = new File(pathname);
		var rezultat = new Rezultat();
		rezultat = getRepetition(root, rezultat);
		System.out.println("Put do najvećeg je " + rezultat.stazaDoNajveceDatoteke);
		Comparator<Map.Entry<String, Integer>> poBrojevima = (p1, p2) -> p2.getValue().compareTo(p1.getValue());
		Comparator<Map.Entry<String, Integer>> poEkstenzijama = (p1, p2) -> p1.getKey().compareTo(p2.getKey());
		List<Map.Entry<String, Integer>> lista = new ArrayList<>(rezultat.ekstenzije.entrySet());
		lista.sort(poBrojevima.thenComparing(poEkstenzijama));
		lista.forEach((e) -> System.out.printf("%s -> %d\n", e.getKey(), e.getValue()));
	}

	private static Rezultat getRepetition(File f, Rezultat rezultat) {
		File[] child = f.listFiles();
		if (child != null) {
			for (File file : child) {
				if (file.isFile()) {
					String ekstenzija = getEkstenzija(file);
					rezultat.ekstenzije.compute(ekstenzija, (k, v) -> v == null ? 1 : v+1);
					if(file.length() > rezultat.velicinaNajveceDatoteke) {
						rezultat.stazaDoNajveceDatoteke = file.getAbsoluteFile();
						rezultat.velicinaNajveceDatoteke = file.length();
					}
				} else if (file.isDirectory()) {
					rezultat = getRepetition(file, rezultat);
				}
			}
		}
		return rezultat;
	}

	private static String getEkstenzija(File file) {
		String name = file.getName();
		if (name.lastIndexOf('.') > 0) {
			String ekst = name.substring(name.lastIndexOf('.') + 1).toLowerCase();
			return ekst;
		}	
		return "";
	}

}