package hr.fer.zemris.java.pred06;

import java.io.File;

public class Stablo {

	
	public static void main(String[] args) {
		String pathname = args[0];
		File root = new File(pathname);
		getStablo(root, 0);
	}

	private static void getStablo(File f, int razina) {
		File[] child = f.listFiles();
		if (child != null) {
			for (File file : child) {
				if (file.isFile()) {
					int i = 0;
					while(i < razina) {
						System.out.print("  ");
						i++;
					}
					System.out.printf("%s\n", file.getPath());
				} else if (file.isDirectory()) {
					int i = 0;
					while(i < razina) {
						System.out.print("  ");
						i++;
					}
					System.out.printf("%s\n", file.getPath());
					getStablo(file, razina + 1);
				}
			}
		}
	}

}