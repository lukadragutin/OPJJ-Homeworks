package hr.fer.zemris.java.pred06;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeSet;

public class Ekstenzije {

	public static void main(String[] args) {

		System.out.println("Unesite put do direktorija: ");
		Scanner sc = new Scanner(System.in);
		String pathname = sc.nextLine();
		sc.close();
		HashMap<String, Integer> ekstenzije = new HashMap<>();
		File root = new File(pathname);
		getRepetition(root, ekstenzije);
		System.out.println("Ekstenzija -> broj ponavljanja");
		Comparator<Map.Entry<String, Integer>> poBrojevima = (p1,p2) -> p2.getValue().compareTo(p1.getValue());
		Comparator<Map.Entry<String, Integer>> poEkstenzijama = (p1,p2) -> p2.getKey().compareTo(p1.getKey());
		List<Map.Entry<String, Integer>> lista = new ArrayList<>(ekstenzije.entrySet());
		lista.sort(poBrojevima.thenComparing(poEkstenzijama));
		lista.forEach((e) -> System.out.printf("%s -> %d\n", e.getKey(), e.getValue()));
	}

	private static void getRepetition(File f, HashMap<String, Integer> ekstenzije) {
		File[] child = f.listFiles();
		if (child != null) {
			for (File file : child) {
				if (file.isFile()) {
					String name = file.getName();
					if (name.contains(".") && name.lastIndexOf('.') != 0) {
						String ekst = name.substring(name.lastIndexOf('.') + 1).toLowerCase();
						ekstenzije.compute(ekst, (k, v) -> v == null ? 1 : v++);
					} else if (!name.contains(".")) {
						ekstenzije.merge("", 1, (k, v) -> v++);
					}
				} else if (file.isDirectory()) {
					getRepetition(file, ekstenzije);
				}
			}
		}
	}
}
