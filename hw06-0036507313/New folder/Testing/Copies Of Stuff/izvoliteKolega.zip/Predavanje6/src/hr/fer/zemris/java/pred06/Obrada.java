package hr.fer.zemris.java.pred06;

import java.io.File;

public interface Obrada {

	void ulazimUDirektorij(File dir);
	void izlazimIzDirektorija(File dir);
	void imamDatoteku(File dir);
	
}
